package demo10;

import java.io.FileNotFoundException;
import java.io.IOException;

class SuperClass {
    public void doSomething() throws IOException {
        System.out.println("This is super class");
    }
}

class SubClass extends SuperClass {
    // This is not allowed, it will result in a compile-time error
    public void doSomething() throws FileNotFoundException {
        System.out.println("This is sub class");
    }
}

public class Demo10 {
    public static void main(String[] args) throws IOException  {
        SuperClass superClass = new SuperClass();
        SubClass subClass = new SubClass();
        
        try {
            superClass.doSomething();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        try {
            subClass.doSomething();
        } finally {
        	System.out.println("This is finally block");
        }
    }
}
