package demo12;

public class Demo12 {
	

	protected void finalize() throws Throwable { 
		try {
			System.out.println("This is try Block");
			}
			finally {
			System.out.println("This is finally block");
			}
		}

	public static void main(String[] args) throws Throwable {
	final int a=10;
	System.out.println(a);
	Demo12 d= new Demo12();
	d.finalize();
	
		}
}
