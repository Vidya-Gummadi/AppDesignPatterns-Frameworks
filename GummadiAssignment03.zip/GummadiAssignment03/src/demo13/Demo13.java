package demo13;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class Demo13 {
	public static void main (String[] args) {
        ArrayList<String> al = new ArrayList<String>();
        al.add("Vidya");
        al.add("Raja");
        al.add("Rajeswari");
        al.add("Gummadi");
        System.out.println("ArrayList elements are:");
        Iterator it = al.iterator();
        while (it.hasNext())
            System.out.println(it.next());
  
        Vector<String> v = new Vector<String>();
        v.addElement("Vigna");
        v.addElement("Naga");
        v.addElement("Santhoshi");
        v.addElement("Gummadi");
        System.out.println("\nVector elements are:");
        Enumeration<String> e = v.elements();
        while (e.hasMoreElements())
           System.out.println(e.nextElement());
    }

}
