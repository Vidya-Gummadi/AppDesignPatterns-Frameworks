package demo15;

import java.util.HashMap;
import java.util.Hashtable;

public class Demo15 {
	    public static void main(String[] args) {
	        Hashtable<String, Integer> Cricketers = new Hashtable<>();
	        Cricketers.put("Virat", 33);
	        Cricketers.put("Dhoni", 38);
	        Cricketers.put("Rohit", 34);

	        for (String name : Cricketers.keySet()) {
	            int age = Cricketers.get(name);
	            System.out.println(name + "'s age is: " + age);
	        }
	        System.out.println("Using HashMap");
	    HashMap<String, Integer> Cricketer = new HashMap<>();
	    Cricketer.put("Virat", 33);
        Cricketer.put("Dhoni", 38);
        Cricketer.put("Rohit", 34);

        for (String name : Cricketer.keySet()) {
            int age = Cricketer.get(name);
            System.out.println(name + "'s age is: " + age);
        }
	 }  

}
