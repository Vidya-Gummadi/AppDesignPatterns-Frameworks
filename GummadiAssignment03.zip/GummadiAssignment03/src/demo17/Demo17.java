package demo17;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class Demo17 {
	public static void main(String[] args) {
	
	List<Integer> list = new CopyOnWriteArrayList<>();
	list.add(1);
	list.add(2);
	list.add(3);

	Iterator<Integer> iterator = list.iterator();

	while (iterator.hasNext()) {
	    Integer value = iterator.next();
	    System.out.println(value);
	    list.remove(value); // modification during iteration
	}
	List<Integer> l = new ArrayList<>();
	l.add(1);
	l.add(2);
	l.add(3);

	Iterator<Integer> itr = l.iterator();

	while (itr.hasNext()) {
	    Integer value = itr.next();
	    System.out.println(value);
	    l.remove(value); // modification during iteration
	}
	
  }
	
}
