package demo19;

public class Demo19Thread extends Thread {
	    public void run() {
	        System.out.println("Thread is running.");
	    }
	    
	    public class MyRunnable implements Runnable {
	        public void run() {
	            System.out.println("Thread is running.");
	        }
	    }
    public static void main(String args[]) {
	// Creating and starting a thread object
	Demo19Thread myThread = new Demo19Thread();
	myThread.start();
	Demo19Thread myRunnable = new Demo19Thread();
	Thread myThread1 = new Thread(myRunnable);
	myThread1.start();

    }
}
