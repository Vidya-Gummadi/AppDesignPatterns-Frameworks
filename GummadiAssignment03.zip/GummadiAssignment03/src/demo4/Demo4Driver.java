package demo4;

public class Demo4Driver {
	    public static void main(String[] args) {
	        Demo41.publicMethod(); // Output: This is a public method in superclass.
	        Demo42.publicMethod(); // Output: This is a public method in subclass.

	       // Demo41.privateMethod(); // Error: The method privateMethod() from the type Superclass is not visible
	        //Demo42.privateMethod(); // Error: The method privateMethod() from the type Subclass is not visible
	    }
}
